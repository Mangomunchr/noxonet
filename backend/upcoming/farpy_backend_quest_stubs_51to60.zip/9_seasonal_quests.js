
// Placeholder: define seasonal/global quests shared by all players (e.g., Chaos Month)
