
// Placeholder: NodeMonks get faster progress or bigger quest rewards
