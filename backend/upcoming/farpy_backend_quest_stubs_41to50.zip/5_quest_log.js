
// Placeholder: store completed quests in separate archive per Rendar, viewable in frontend
