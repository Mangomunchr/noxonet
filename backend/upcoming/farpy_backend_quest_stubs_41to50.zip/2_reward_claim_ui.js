
// Placeholder: add frontend route/button to manually claim rewards instead of automatic apply
